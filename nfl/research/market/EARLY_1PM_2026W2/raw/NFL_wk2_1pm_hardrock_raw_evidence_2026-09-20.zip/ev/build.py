import json,glob,csv,datetime,collections
pmap=json.load(open('pmap.json')); log=json.load(open('fetchlog.json'))
logmap={(l['game'],l['group']):l for l in log}
ABBR={'Philadelphia Eagles':'PHI','Tennessee Titans':'TEN','Pittsburgh Steelers':'PIT','New England Patriots':'NE','Minnesota Vikings':'MIN','Chicago Bears':'CHI','Carolina Panthers':'CAR','Atlanta Falcons':'ATL','Green Bay Packers':'GB','New York Jets':'NYJ','New Orleans Saints':'NO','Baltimore Ravens':'BAL','Cincinnati Bengals':'CIN','Houston Texans':'HOU','Cleveland Browns':'CLE','Tampa Bay Buccaneers':'TB'}
rows=[]; team_mismatch=[]
for f in sorted(glob.glob('raw/*.json')):
    game=f.split('/')[-1].split('__')[0].replace('_at_','@'); gi=int(f.split('__g')[1].split('.')[0])
    L=logmap[(game,gi)]
    s=open(f).read().split('\n<<STDERR>>')[0]; d,_=json.JSONDecoder().raw_decode(s)
    fx=d['result']['data']['data'][0]
    away=ABBR[fx['away_team_display']]; home=ABBR[fx['home_team_display']]
    g=collections.defaultdict(dict)
    for o in fx['odds']:
        g[(o['market_id'],o['market'],o.get('selection'),o.get('points'),o.get('player_id'),o.get('is_main'),o.get('team_id'))][o.get('selection_line') or 'yes']=o
    for (mid,mname,sel,pts,pid,ismain,tid),sides in g.items():
        ov,un,yes=sides.get('over'),sides.get('under'),sides.get('yes')
        if pid:
            nm,teamfull,pos=pmap[pid]; team=ABBR.get(teamfull,'')
            if team not in (away,home): team_mismatch.append((nm,teamfull,game)); team=''
            displayed=sel
            if nm!=sel: nm_out='IDENTITY_UNRESOLVED'; pos=pos or ''
            else: nm_out=nm
            opp=(home if team==away else away) if team else ''
        else:
            displayed=sel; nm_out=''; pos=''
            team=ABBR.get(sel,'') if mid in ('moneyline','point_spread','team_total') else ''
            opp=(home if team==away else away) if team else ''
        if yes: status='open_single_selection'
        elif ov and un: status='open_two_sided'
        else: status='open_one_sided_'+('over' if ov else 'under')
        ts=max(o['timestamp'] for o in sides.values())
        rows.append(dict(
            retrieved_at_utc=L['requested_at_utc'][:19]+'Z',
            book='Hard Rock Bet',game_id=fx['id'],game=game,away_team=away,home_team=home,kickoff_utc=fx['start_date'],
            player=nm_out,displayed_selection=displayed,team=team,opponent=opp,position=pos,
            market=mname,market_id=mid,market_class=('player_prop' if pid else 'game_or_team'),is_main_line=ismain,
            line=('' if pts is None else pts),
            over_price=(ov['price'] if ov else ''),under_price=(un['price'] if un else ''),
            selection_price=(yes['price'] if yes else ''),
            market_status=status,
            book_line_timestamp_utc=datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat().replace('+00:00','Z'),
            odds_id_over=(ov['id'] if ov else (yes['id'] if yes else '')),odds_id_under=(un['id'] if un else ''),
            source_url=((ov or un or yes)['deep_link'] or {}).get('ios',''),
            source_endpoint='OpticOdds API v3 GET /fixtures/odds?fixture_id=%s&sportsbook=Hard Rock&market=%s'%(fx['id'],mid),
            evidence_type='structured_json_api_response',raw_file=f))
rows.sort(key=lambda r:(r['game'],r['market_class']!='player_prop',r['market'],r['player'],r['displayed_selection'],float(r['line']) if r['line']!='' else 0))
cols=list(rows[0].keys())
tag='2026-09-20T0452Z'
with open(f'NFL_wk2_1pm_hardrock_markets_{tag}.csv','w',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=cols); w.writeheader(); w.writerows(rows)
json.dump(rows,open(f'NFL_wk2_1pm_hardrock_markets_{tag}.json','w'),indent=1)
print(len(rows),collections.Counter(r['market_status'] for r in rows))
print("team_mismatch",team_mismatch[:10],len(team_mismatch))
print("unresolved",sum(r['player']=='IDENTITY_UNRESOLVED' for r in rows))
# completeness
pp=[r for r in rows if r['market_class']=='player_prop']
print("games",len(set(r['game'] for r in rows)))
print("unique player-markets (player,market,game)",len(set((r['player'],r['market'],r['game']) for r in pp)))
print("unique player-market-lines",len(pp))
print("paired two-sided player rows",sum(r['market_status']=='open_two_sided' for r in pp))
print("one-sided player rows",sum(r['market_status'].startswith('open_one_sided') for r in pp))
print("single-selection (yes) player rows",sum(r['market_status']=='open_single_selection' for r in pp))
main=[r for r in pp if r['is_main_line']]
print("MAIN-LINE player rows",len(main),collections.Counter(r['market_status'] for r in main))
print(collections.Counter(r['market'] for r in main))
# per game main lines
for gname in sorted(set(r['game'] for r in rows)):
    gm=[r for r in rows if r['game']==gname and r['is_main_line']]
    print(gname, {k:v for k,v in collections.Counter(r['market'] for r in gm).items()})
