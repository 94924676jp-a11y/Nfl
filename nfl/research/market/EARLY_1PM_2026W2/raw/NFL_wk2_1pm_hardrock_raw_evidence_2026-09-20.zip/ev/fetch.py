import json,subprocess,datetime,os,sys
FIX={"PHI@TEN":"202609208AD46BE9","PIT@NE":"202609208CF5F830","MIN@CHI":"20260920AEBD0307","CAR@ATL":"20260920E9718F0E",
     "GB@NYJ":"202609207339899F","NO@BAL":"20260920941629C7","CIN@HOU":"202609203726483F","CLE@TB":"20260920ABAE4147"}
# priority order: game lines, QB, RB/WR/TE primary, TD, secondary
GROUPS=[
 ["moneyline","point_spread","total_points"],
 ["player_passing_yards","player_passing_touchdowns","player_interceptions","player_passing_completions","player_passing_attempts","player_longest_passing_completion"],
 ["player_rushing_yards","player_rushing_attempts","player_receiving_yards","player_receptions","player_rushing_+_receiving_yards"],
 ["player_touchdowns"],
 ["player_longest_reception","player_longest_rush","player_receiving_targets","team_total","player_field_goals_made","player_kicking_points"],
]
os.makedirs("raw",exist_ok=True)
log=[]
for gi,grp in enumerate(GROUPS):
  for game,fid in FIX.items():
    inp=json.dumps({"path":"/fixtures/odds","params":{"fixture_id":fid,"sportsbook":"Hard Rock","market":grp}})
    ts=datetime.datetime.now(datetime.timezone.utc).isoformat()
    r=subprocess.run(["pplx","connector","call","opticodds","opticodds","--input",inp],capture_output=True,text=True)
    fn=f"raw/{game.replace('@','_at_')}__g{gi}.json"
    open(fn,"w").write(r.stdout+("\n<<STDERR>>\n"+r.stderr if r.stderr else ""))
    try:
        d,_=json.JSONDecoder().raw_decode(r.stdout)
        sc=d['result'].get('status_code'); dd=d['result']['data']['data']
        n=len(dd[0]['odds']) if dd else 0
    except Exception as e:
        sc='ERR'; n=repr(e)[:80]
    log.append(dict(game=game,fixture_id=fid,group=gi,markets=grp,requested_at_utc=ts,status_code=sc,n_odds=n,file=fn))
    print(gi,game,ts,sc,n,flush=True)
json.dump(log,open("fetchlog.json","w"),indent=1)
